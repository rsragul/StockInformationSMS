package com.example.rahulraman_comp304_001_test02.RoomDatabase;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import com.example.rahulraman_comp304_001_test02.View.StockInfo;

import java.util.List;

@Dao
public interface StockInfoDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertDetails(StockInfo data);

    @Query("select * from StockInfo")
    LiveData<List<StockInfo>> getDetails();

    @Query("delete from StockInfo")
    void deleteAllData();

    @Query("select * from StockInfo where StockSymbol = :pId")
    LiveData<StockInfo> getselectedStock(String pId);
}
