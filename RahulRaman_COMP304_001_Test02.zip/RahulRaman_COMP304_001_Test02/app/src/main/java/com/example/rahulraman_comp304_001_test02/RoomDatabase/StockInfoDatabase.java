package com.example.rahulraman_comp304_001_test02.RoomDatabase;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

import com.example.rahulraman_comp304_001_test02.View.StockInfo;

@Database(entities = {StockInfo.class}, version = 1, exportSchema = false)
public abstract class StockInfoDatabase extends RoomDatabase {

    public abstract StockInfoDao stockInfoDao();

    private static StockInfoDatabase INSTANCE;

    public static StockInfoDatabase getDatabase(final Context context) {

        if (INSTANCE == null) {

            synchronized (StockInfoDatabase.class) {

                if (INSTANCE == null) {

                    INSTANCE = Room.databaseBuilder(
                            context, StockInfoDatabase.class, "STOCK_INFO_DATABASE")
                            .fallbackToDestructiveMigration()
                            .build();
                }
            }
        }
        return INSTANCE;

    }

}
