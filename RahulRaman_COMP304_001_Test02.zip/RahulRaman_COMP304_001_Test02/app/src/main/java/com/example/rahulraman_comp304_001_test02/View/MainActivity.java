package com.example.rahulraman_comp304_001_test02.View;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import com.example.rahulraman_comp304_001_test02.R;
import com.example.rahulraman_comp304_001_test02.ViewModel.StockInfoViewModel;

import java.util.ArrayList;
import java.util.List;

import static android.Manifest.permission.SEND_SMS;


public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Button displayButton, insertDataButton;
    RadioButton radioSMS, radioGoogle, radioAmazon, radioSSNLF;
    StockInfo stockInfo;
    StockInfoViewModel stockInfoViewModel;
    TextView tvCompanyName, tvStockQuote;
    String selectedMSG = "";
    String[] PERMISSIONS = {
            SEND_SMS
    };
    private static final int SMS_PERMISSION = 0;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        displayButton = findViewById(R.id.btnDisplay);
        displayButton.setOnClickListener(this);
        radioSMS = findViewById(R.id.radioSMS);
        radioSSNLF = findViewById(R.id.radioSSNLF);
        radioGoogle = findViewById(R.id.radioGoogle);
        radioAmazon = findViewById(R.id.radioAmazon);
        tvCompanyName = findViewById(R.id.textCompanyName);
        tvStockQuote = findViewById(R.id.textStockQuote);
        insertDataButton = findViewById(R.id.btnInsertData);
        insertDataButton.setOnClickListener(this);
        stockInfoViewModel = ViewModelProviders.of(this).get(StockInfoViewModel.class);
        stockInfoViewModel.getInsertResult().observe(this, new Observer<Integer>() {
            @Override
            public void onChanged(@Nullable Integer result) {
                if (result == 1) {
                    Toast.makeText(MainActivity.this, "Stock Data saved", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(MainActivity.this, "Error saving stock data", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

    private void insertData() {

        stockInfo = new StockInfo(getResources().getString(R.string.google2), getResources().getString(R.string.google), 1575.57);
        stockInfoViewModel.insert(stockInfo);

        stockInfo = new StockInfo(getResources().getString(R.string.amazon2), getResources().getString(R.string.amazon), 3284.72);
        stockInfoViewModel.insert(stockInfo);

        stockInfo = new StockInfo(getResources().getString(R.string.ssnlf2), getResources().getString(R.string.ssnlf), 600);
        stockInfoViewModel.insert(stockInfo);

    }

    @Override
    public void onClick(View view) {
        int id = view.getId();
        if (id == R.id.btnDisplay) {
            getData();
        } else if (id == R.id.btnInsertData) {
            insertData();
            tvCompanyName.setText("");
            tvStockQuote.setText("");
        }
    }

    private void getData() {
        String selectedStock = "";
        if (radioAmazon.isChecked()) {
            selectedStock = radioAmazon.getText().toString();
        } else if (radioGoogle.isChecked()) {
            selectedStock = radioGoogle.getText().toString();
        } else if (radioSSNLF.isChecked()) {
            selectedStock = radioSSNLF.getText().toString();
        } else {
            selectedStock = radioAmazon.getText().toString();
        }
        ShowOnUI(selectedStock);
        sendMsg(tvCompanyName.getText().toString() + "\n" + tvStockQuote.getText().toString());
    }
    private void ShowOnUI(String selectedStock) {
        stockInfoViewModel.getSpecificStock(selectedStock).observe(this, new Observer<StockInfo>() {
            @Override
            public void onChanged(StockInfo stockInfo) {
                if (stockInfo != null) {
                    tvCompanyName.setText("Company Name: " + stockInfo.getCompanyName());
                    tvStockQuote.setText("Stock Quote: " + String.valueOf(stockInfo.getStockQuote()));
                }
            }
        });
    }

    private void sendMsg(String msg) {
        if(radioSMS.isChecked()){
            selectedMSG = msg;
            requestpermission();
        }
       /* if (radioEmail.isChecked()) {
            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.putExtra(Intent.EXTRA_EMAIL, new String[]{"test@gmail.com"});
            intent.putExtra(Intent.EXTRA_SUBJECT, "Company Stock Info");
            intent.putExtra(Intent.EXTRA_TEXT, msg);
            intent.setType("message/rfc822");
            startActivity(Intent.createChooser(intent, "Choose Mail App"));

        }*/
    }
    private void requestpermission() {
        int result;
        List<String> listPermissionsNeeded = new ArrayList<>();
        for (String p : PERMISSIONS) {
            result = ContextCompat.checkSelfPermission(MainActivity.this, p);
            if (result != PackageManager.PERMISSION_GRANTED) {
                listPermissionsNeeded.add(p);
            }
        }
        if (!listPermissionsNeeded.isEmpty()) {
            ActivityCompat.requestPermissions(MainActivity.this,
                    listPermissionsNeeded.toArray(new String[listPermissionsNeeded.size()]), SMS_PERMISSION);
        } else {
            SendSMS(selectedMSG);
        }
    }

    private void SendSMS(String msg) {
        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage("5554", null, msg, null, null);
            Toast.makeText(this, "SMS sent successfully", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "SMS Failed to Send, Please try again", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        if (requestCode == SMS_PERMISSION) {
            if (grantResults.length > 0
                    && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                SendSMS(selectedMSG);
            } else {
                Toast.makeText(getApplicationContext(),
                        "SMS failed, please try again.", Toast.LENGTH_LONG).show();
            }
        }

    }

}