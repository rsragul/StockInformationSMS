package com.example.rahulraman_comp304_001_test02.ViewModel;


import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.example.rahulraman_comp304_001_test02.Repository.StockInfoRepository;
import com.example.rahulraman_comp304_001_test02.RoomDatabase.StockInfoDao;
import com.example.rahulraman_comp304_001_test02.View.StockInfo;

import java.util.List;

public class StockInfoViewModel extends AndroidViewModel {
    // calling repository tasks and
    // sending the results to the Activity
    private StockInfoRepository stockInfoRepository;
    private LiveData<Integer> insertResult;
    private LiveData<List<StockInfo>> allStock;
    private StockInfoDao stockInfoDao;

    public StockInfoViewModel(@NonNull Application application) {
        super(application);
        stockInfoRepository = new StockInfoRepository(application);
        insertResult = stockInfoRepository.getInsertResult();
        allStock = stockInfoRepository.getAllData();
    }

    //calls repository to insert a patient
    public void insert(StockInfo stockInfo) {
        stockInfoRepository.insertData(stockInfo);
    }

    //gets insert results as LiveData object
    public LiveData<Integer> getInsertResult() {
        return insertResult;
    }

    //returns query results as live data object
    public LiveData<List<StockInfo>> getAllResults() {
        return allStock;
    }

    public LiveData<StockInfo> getSpecificStock(String stockSymbol) {
        return stockInfoRepository.getSelectedStock(stockSymbol);
    }


}
